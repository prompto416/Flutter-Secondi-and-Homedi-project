import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class DetailPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
