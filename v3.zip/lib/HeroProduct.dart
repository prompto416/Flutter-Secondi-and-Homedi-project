import 'package:flutter/material.dart';

class MyProduct extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        //child: Image.asset("assets/images/house${index + 1}.jpg"),
        );
  }
}
