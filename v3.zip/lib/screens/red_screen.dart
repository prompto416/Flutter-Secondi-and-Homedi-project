import 'package:flutter/material.dart';

class RedScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(color: Colors.red);
  }
}
