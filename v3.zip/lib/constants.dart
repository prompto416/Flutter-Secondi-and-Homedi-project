import 'package:flutter/material.dart';

Color primaryColor = Colors.yellow;

Color secondaryColor = Colors.white;
